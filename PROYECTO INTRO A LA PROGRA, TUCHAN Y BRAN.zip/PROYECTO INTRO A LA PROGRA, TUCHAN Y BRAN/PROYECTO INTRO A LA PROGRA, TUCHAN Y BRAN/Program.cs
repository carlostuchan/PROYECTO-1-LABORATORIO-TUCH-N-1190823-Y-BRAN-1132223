﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO_INTRO_A_LA_PROGRA__TUCHAN_Y_BRAN
{
    internal class Program
 
    {
        static void Main(string[] args)
        {
            int estacionPartida, estacionDestino;
            double distancia, precioBoleto, tiempoEstimado;
            int totalTiempoViajando = 0;
            double totalGastadoBoletos = 0;

            Console.WriteLine("Bienvenido al sistema de compra de boletos del Trasmetro.");

            do
            {
                Console.WriteLine("\nPor favor, ingrese la estación de partida (código):");
                estacionPartida = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese la estación de destino (código):");
                estacionDestino = int.Parse(Console.ReadLine());

                if (ExisteRuta(estacionPartida, estacionDestino, out distancia))
                {
                    Console.WriteLine("Ingrese la fecha de uso del servicio:");
                    string fechaUso = Console.ReadLine();
                    Console.WriteLine("Ingrese su edad:");
                    int edad = int.Parse(Console.ReadLine());
                    Console.WriteLine("¿Está embarazada? (Sí/No):");
                    bool estaEmbarazada = Console.ReadLine().Equals("Sí", StringComparison.OrdinalIgnoreCase);
                    Console.WriteLine("¿Viajará con un niño menor de 3 años? (Sí/No):");
                    bool viajaConNino = Console.ReadLine().Equals("Sí", StringComparison.OrdinalIgnoreCase);

                    precioBoleto = CalcularPrecioBoleto(distancia, edad, estaEmbarazada, viajaConNino);
                    tiempoEstimado = CalcularTiempoEstimado(distancia);

                    Console.WriteLine("\nResumen del viaje:");
                    Console.WriteLine($"- Ruta: Estación {estacionPartida} a Estación {estacionDestino}");
                    Console.WriteLine($"- Tiempo estimado de viaje: {tiempoEstimado} minutos");
                    Console.WriteLine($"- Precio del boleto: Q{precioBoleto:F2}");

                    totalTiempoViajando += (int)tiempoEstimado;
                    totalGastadoBoletos += precioBoleto;

                    Console.WriteLine("\n¿Desea realizar otro viaje? (Sí/No):");
                    string respuesta = Console.ReadLine();
                    if (!respuesta.Equals("Sí", StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine("\nResumen final:");
                        Console.WriteLine($"- Tiempo total viajando: {totalTiempoViajando} minutos");
                        Console.WriteLine($"- Total gastado en boletos: Q{totalGastadoBoletos:F2}");
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("No existe una ruta directa entre las estaciones ingresadas.");
                }
            } while (true);
        }

        static bool ExisteRuta(int estacionPartida, int estacionDestino, out double distancia)
        {
            // Definir las rutas existentes
            int[,] rutas = {
                { 51, 61, 14 },
                { 51, 72, 28 },
                { 71, 82, 13 },
                { 61, 51, 7 },
                { 82, 51, 21 }
            };

            for (int i = 0; i < rutas.GetLength(0); i++)
            {
                if (rutas[i, 0] == estacionPartida && rutas[i, 1] == estacionDestino)
                {
                    distancia = rutas[i, 2];
                    return true;
                }
            }

            distancia = 0;
            return false;
        }

        static double CalcularPrecioBoleto(double distancia, int edad, bool estaEmbarazada, bool viajaConNino)
        {
            double precioBase = distancia <= 10 ? distancia * 0.07 : (10 * 0.07) + ((distancia - 10) * 0.02);

            if (estaEmbarazada || viajaConNino)
            {
                return 0; // Viaje gratis
            }

            if (edad >= 15 && edad <= 25)
            {
                return precioBase * 0.79; // 21% de descuento para estudiantes
            }

            return precioBase;
        }

        static double CalcularTiempoEstimado(double distancia)
        {
            double velocidad = 40; // km/h
            return distancia / velocidad * 60; // minutos
        }
    }
}
